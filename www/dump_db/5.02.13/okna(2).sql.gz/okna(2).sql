-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Фев 05 2013 г., 14:04
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `okna`
--

-- --------------------------------------------------------

--
-- Структура таблицы `categorydemo`
--

CREATE TABLE IF NOT EXISTS `categorydemo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `root` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned NOT NULL,
  `rgt` int(10) unsigned NOT NULL,
  `level` smallint(5) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`),
  KEY `level` (`level`),
  KEY `root` (`root`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=106 ;

--
-- Дамп данных таблицы `categorydemo`
--

INSERT INTO `categorydemo` (`id`, `root`, `lft`, `rgt`, `level`, `name`, `description`) VALUES
(95, 101, 2, 19, 2, 'Category One', ''),
(96, 101, 13, 14, 7, 'Category Two', ''),
(97, 101, 5, 6, 3, 'SubCategory_1A', ''),
(98, 101, 12, 15, 6, 'SubCategory_2A', ''),
(99, 101, 7, 8, 3, 'SubCategory_2B', ''),
(101, 101, 1, 20, 1, '11111111', ''),
(102, 101, 3, 4, 3, '123123', ''),
(103, 101, 9, 18, 3, 'trete', ''),
(104, 101, 10, 17, 4, 'ertert', ''),
(105, 101, 11, 16, 5, 'wer', '');

-- --------------------------------------------------------

--
-- Структура таблицы `edit_fields`
--

CREATE TABLE IF NOT EXISTS `edit_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `position` int(11) NOT NULL,
  `f_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=46 ;

--
-- Дамп данных таблицы `edit_fields`
--

INSERT INTO `edit_fields` (`id`, `key`, `name`, `value`, `position`, `f_type`) VALUES
(1, 'top_logo_alt', 'alt для логотипа в шапке', 'alt для логотипа в шапке1', 10, '0'),
(2, 'top_logo_title', 'title для логотипа в шапке', 'title для логотипа в шапке2', 20, '0'),
(3, 'top_phone', 'номера телефонов в шапке', '<img src="/images/site/header-call-me.png">', 30, 'area'),
(4, 'top_work_time', 'время работы в шапке', '<img src="/images/site/header-work-time.png">', 40, '0'),
(5, 'top_map_alt', 'alt для карты в шапке', 'alt для карты в шапке', 50, '0'),
(6, 'top_map_title', 'title для карты в шапке', 'title для карты в шапке', 60, '0'),
(7, 'start_breadcrumbs', 'заголовок для хлебных крошек', 'Фабрика окон', 70, '0'),
(8, 'foter_logo_alt', 'alt для лого в подвале', 'alt для лого в подвале', 80, '0'),
(9, 'footer_logo_title', 'title для логотипа в подвале', 'title для логотипа в подвале', 100, '0'),
(10, 'footer_phone_1', 'номера телефонов в подвале 1', '(050) 322-16-19', 110, '0'),
(11, 'footer_work_time', 'время работы в подвале', 'Пн-Пт 8:00 - 17:00; Сб-Вс 8:00 - 14:00', 120, '0'),
(12, 'footer_slogan_title', 'заголовок слогана в подвале', 'О нас', 130, '0'),
(13, 'footer_slogan_text', 'текст слогана в подвале', 'текст слогана в подвале', 140, 'area'),
(14, 'footer_soc_title', 'заголовок для списка в соц сетях', 'Мы в популярных сетях', 150, '0'),
(15, 'footer_soc_list', 'список ссылок на соц сети', 'список ссылок на соц сети', 160, 'area'),
(16, 'footer_copyright', 'текст копирайта', 'Copyright &copy; 2012. Все права защищены', 170, '0'),
(17, 'footer_map_alt', 'alt для карты сайта в подвале', 'alt для карты сайта в подвале', 180, '0'),
(18, 'footer_map_title', 'title для карты сайта в подвале', 'title для карты сайта в подвале', 190, '0'),
(19, 'footer_phone_2', 'номера телефонов в подвале 2', '(067) 139-57-57', 112, ''),
(20, 'footer_phone_3', 'номера телефонов в подвале 3', '(061) 220-79-01', 114, '0'),
(21, 'footer_map_text', 'текст для карты сайта в подвале', 'Карта сайта', 200, ''),
(22, 'footer_google_link', 'ссылка на google в подвале', 'http://google.ru', 220, ''),
(23, 'footer_facebook_link', 'ссылка на facebook в подвале', 'http://facebook.com', 225, ''),
(24, 'footer_youtube_link', 'ссылка на youtube в подвале', 'http://youtube.com', 230, ''),
(25, 'footer_vk_link', 'ссылка на "В контакте" в подвале', 'http://vk.com', 235, ''),
(26, 'footer_ok_link', 'ссылка на однокласники в подвале', 'http://ya.ru', 240, ''),
(27, 'footer_ok_link', 'ссылка на твитер в подвале', 'https://twitter.com', 245, ''),
(28, 'left_blog', 'заголовок блога', 'Наш блог', 500, ''),
(29, 'left_last_info', 'заголовок последних статей', 'Свежие статьи', 505, ''),
(31, 'right_banners', 'Баннеры слева', '                    <div class="right-banners">\r\n                    <img src="/images/site/b1.png">\r\n                    </div>\r\n                    <div class="right-banners">\r\n                        <img src="/images/site/b2.png">\r\n                    </div>', 1000, ''),
(32, 'right_consul_header', 'заголовок для консультанта', 'Ваш консультант', 1010, ''),
(33, 'right_foto_consul', 'Фото консультанта', '<img src="/images/site/foto-m.jpg">', 1050, ''),
(34, 'right_consul_name', 'имя консультанта', 'Настя Бондарева', 1060, ''),
(35, 'right_phone_header', 'заголовок для телефонов справа', 'Звоните Сейчас!', 2000, ''),
(36, 'right_phone_phone_1', 'телефон справа 1', '(050) 322-16-19', 2010, ''),
(37, 'right_phone_phone_2', 'телефон справа 2', '(067) 139-57-57', 2020, ''),
(38, 'right_phone_phone_3', 'телефон справа 3', '(061) 220-79-01', 2030, ''),
(39, 'right_video_header', 'заголовок для видео', 'Окна для каждого', 3000, ''),
(40, 'right_video_link', 'ссылка на видео', '', 3010, ''),
(41, 'right_otz_header', 'заголовок для отзывов', 'О нас говорят', 3200, ''),
(42, 'right_otz_link_text', 'текст ссылки ведущая на отзывовы', 'Все отзывы', 3210, ''),
(43, 'right_otz_link', 'ссылка на отзывы', '/reviews', 3220, ''),
(44, 'news_list_text', 'текст ссылки "подробнее" в списке новостей', 'Подробнее...', 4000, ''),
(45, 'left_last_info', 'количество выводимых последних статей слева', '3', 510, '');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `menu_name` varchar(255) NOT NULL,
  `h1` varchar(255) NOT NULL,
  `short_text` text NOT NULL,
  `text` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_title` text NOT NULL,
  `date` int(11) NOT NULL,
  `visibility` tinyint(1) NOT NULL,
  `in_main` tinyint(1) NOT NULL,
  `img_alt` varchar(255) NOT NULL,
  `img_title` varchar(255) NOT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`news_id`, `url`, `menu_name`, `h1`, `short_text`, `text`, `img`, `meta_keywords`, `meta_description`, `meta_title`, `date`, `visibility`, `in_main`, `img_alt`, `img_title`) VALUES
(6, 'ewrewerw', 'Окна Днепропетровск - фабрика окон Окна Днепропетровск - фабрика окон Окна Днепропетровск - фабрика окон Окна Днепропетровск - фабрика окон', 'Окна Днепропетровск - фабрика окон', '<p>Окна Днепропетровск - фабрика окон</p>', '<p>Окна Днепропетровск - фабрика окон</p>', '6_diamond_white.jpg', 'Окна Днепропетровск - фабрика окон', 'Окна Днепропетровск - фабрика окон', 'Окна Днепропетровск - фабрика окон', 1357164000, 1, 0, '', ''),
(7, 'test1123', 'Немецкое качество', 'Немецкое качество', '<p>Немецкое качество</p>', '<p>Немецкое качество</p>', '7_diamondAllianceIndex01.jpg', 'Немецкое качество', 'Немецкое качество', 'Немецкое качество', 1359151200, 1, 0, '123', '12321321332'),
(8, 'asdasdasdsadsad', 'Металлопластиковые окна Rehau в детский дом семейного типа', 'Металлопластиковые окна Rehau в детский дом семейного типа', '<p><span style="color: #000000; font-size: 12px; font-family: tahoma, geneva, sans-serif;">Компания  Открытые окна заботится не только о совершенствовании и развитии своего  бизнеса, но и принимает активное участие в благотворительной  деятельности, помогая родителям дарящим приемным детям семью и  родительский уют.</span></p>', '<p><span style="color: #000000; font-size: 12px; font-family: tahoma, geneva, sans-serif;">Компания  Открытые окна заботится не только о совершенствовании и развитии своего  бизнеса, но и принимает активное участие в благотворительной  деятельности, помогая родителям дарящим приемным детям семью и  родительский уют.</span></p>\r\n<p><br /><span style="color: #000000; font-size: 12px; font-family: tahoma, geneva, sans-serif;">Компания  Открытые окна заботится не только о совершенствовании и развитии своего  бизнеса, но и принимает активное участие в благотворительной  деятельности, помогая родителям дарящим приемным детям семью и  родительский уют.</span></p>\r\n<p><br /><span style="color: #000000; font-size: 12px; font-family: tahoma, geneva, sans-serif;">Компания  Открытые окна заботится не только о совершенствовании и развитии своего  бизнеса, но и принимает активное участие в благотворительной  деятельности, помогая родителям дарящим приемным детям семью и  родительский уют.</span></p>\r\n<p><br /><span style="color: #000000; font-size: 12px; font-family: tahoma, geneva, sans-serif;">Компания  Открытые окна заботится не только о совершенствовании и развитии своего  бизнеса, но и принимает активное участие в благотворительной  деятельности, помогая родителям дарящим приемным детям семью и  родительский уют.</span><span style="color: #000000; font-size: 12px; font-family: tahoma, geneva, sans-serif;">Компания  Открытые окна заботится не только о совершенствовании и развитии своего  бизнеса, но и принимает активное участие в благотворительной  деятельности, помогая родителям дарящим приемным детям семью и  родительский уют.</span><span style="color: #000000; font-size: 12px; font-family: tahoma, geneva, sans-serif;">Компания  Открытые окна заботится не только о совершенствовании и развитии своего  бизнеса, но и принимает активное участие в благотворительной  деятельности, помогая родителям дарящим приемным детям семью и  родительский уют.</span><span style="color: #000000; font-size: 12px; font-family: tahoma, geneva, sans-serif;">Компания  Открытые окна заботится не только о совершенствовании и развитии своего  бизнеса, но и принимает активное участие в благотворительной  деятельности, помогая родителям дарящим приемным детям семью и  родительский уют.</span></p>\r\n<p><br /><span style="color: #000000; font-size: 12px; font-family: tahoma, geneva, sans-serif;">Компания  Открытые окна заботится не только о совершенствовании и развитии своего  бизнеса, но и принимает активное участие в благотворительной  деятельности, помогая родителям дарящим приемным детям семью и  родительский уют.</span></p>', '8_123.jpg', 'Металлопластиковые окна Rehau в детский дом семейного типа', 'Металлопластиковые окна Rehau в детский дом семейного типа', 'Металлопластиковые окна Rehau в детский дом семейного типа', 1359583200, 1, 0, '1', '2'),
(9, 'advf7675', 'Солнцезащита улучшилась!', 'Солнцезащита улучшилась!', '<p><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Но  в некоторых случаях ролшторы &ndash; экономная альтернатива классическим  шторам. Особенной популярностью рулонные шторы пользуются у жителей  &laquo;малометражек&raquo;, ведь классические шторы занимают хоть небольшое, но  ощутимое место рядом с окном. Раньше здесь планировали быть шторы, а  теперь стоит рабочая поверхность кухни. В данном случае рулонные шторы  сэкономили полезную площадь жилого помещения.</span></span></span></p>', '<p><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Но  в некоторых случаях ролшторы &ndash; экономная альтернатива классическим  шторам. Особенной популярностью рулонные шторы пользуются у жителей  &laquo;малометражек&raquo;, ведь классические шторы занимают хоть небольшое, но  ощутимое место рядом с окном. Раньше здесь планировали быть шторы, а  теперь стоит рабочая поверхность кухни. В данном случае рулонные шторы  сэкономили полезную площадь жилого помещения.</span></span></span></p>\r\n<p><br /><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Но  в некоторых случаях ролшторы &ndash; экономная альтернатива классическим  шторам. Особенной популярностью рулонные шторы пользуются у жителей  &laquo;малометражек&raquo;, ведь классические шторы занимают хоть небольшое, но  ощутимое место рядом с окном. Раньше здесь планировали быть шторы, а  теперь стоит рабочая поверхность кухни. В данном случае рулонные шторы  сэкономили полезную площадь жилого помещения.</span></span></span></p>\r\n<p><br /><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Но  в некоторых случаях ролшторы &ndash; экономная альтернатива классическим  шторам. Особенной популярностью рулонные шторы пользуются у жителей  &laquo;малометражек&raquo;, ведь классические шторы занимают хоть небольшое, но  ощутимое место рядом с окном. Раньше здесь планировали быть шторы, а  теперь стоит рабочая поверхность кухни. В данном случае рулонные шторы  сэкономили полезную площадь жилого помещения.</span></span></span></p>\r\n<p><br /><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Но  в некоторых случаях ролшторы &ndash; экономная альтернатива классическим  шторам. Особенной популярностью рулонные шторы пользуются у жителей  &laquo;малометражек&raquo;, ведь классические шторы занимают хоть небольшое, но  ощутимое место рядом с окном. Раньше здесь планировали быть шторы, а  теперь стоит рабочая поверхность кухни. В данном случае рулонные шторы  сэкономили полезную площадь жилого помещения.</span></span></span></p>', '', 'Солнцезащита улучшилась!', 'Солнцезащита улучшилась!', 'Солнцезащита улучшилась!', 1359583200, 1, 0, '', ''),
(10, 'sadf324', '«Открытые Окна» на выставке «Фасад - 2012»', '«Открытые Окна» на выставке «Фасад - 2012»', '<p><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">15-17  марта 2012 года в Днепропетровске прошла 23-я Национальная выставка  строительства и архитектуры &laquo;Фасад весна &ndash; 2012&raquo;. &nbsp;Выставка проходила в  Экспо-центре &laquo;Метеор&raquo;.</span></span></span></p>\r\n<p><br /><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">15-17  марта 2012 года в Днепропетровске прошла 23-я Национальная выставка  строительства и архитектуры &laquo;Фасад весна &ndash; 2012&raquo;. &nbsp;Выставка проходила в  Экспо-центре &laquo;Метеор&raquo;.</span></span></span></p>\r\n<p><br /><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">15-17  марта 2012 года в Днепропетровске прошла 23-я Национальная выставка  строительства и архитектуры &laquo;Фасад весна &ndash; 2012&raquo;. &nbsp;Выставка проходила в  Экспо-центре &laquo;Метеор&raquo;.</span></span></span></p>\r\n<p><br /><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">15-17  марта 2012 года в Днепропетровске прошла 23-я Национальная выставка  строительства и архитектуры &laquo;Фасад весна &ndash; 2012&raquo;. &nbsp;Выставка проходила в  Экспо-центре &laquo;Метеор&raquo;.</span></span></span></p>\r\n<p><br /><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">15-17  марта 2012 года в Днепропетровске прошла 23-я Национальная выставка  строительства и архитектуры &laquo;Фасад весна &ndash; 2012&raquo;. &nbsp;Выставка проходила в  Экспо-центре &laquo;Метеор&raquo;.</span></span></span><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">15-17  марта 2012 года в Днепропетровске прошла 23-я Национальная выставка  строительства и архитектуры &laquo;Фасад весна &ndash; 2012&raquo;. &nbsp;Выставка проходила в  Экспо-центре &laquo;Метеор&raquo;.</span></span></span><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">15-17  марта 2012 года в Днепропетровске прошла 23-я Национальная выставка  строительства и архитектуры &laquo;Фасад весна &ndash; 2012&raquo;. &nbsp;Выставка проходила в  Экспо-центре &laquo;Метеор&raquo;.</span></span></span><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">15-17  марта 2012 года в Днепропетровске прошла 23-я Национальная выставка  строительства и архитектуры &laquo;Фасад весна &ndash; 2012&raquo;. &nbsp;Выставка проходила в  Экспо-центре &laquo;Метеор&raquo;.</span></span></span></p>', '', '', '«Открытые Окна» на выставке «Фасад - 2012»', '«Открытые Окна» на выставке «Фасад - 2012»', '«Открытые Окна» на выставке «Фасад - 2012»', 1359583200, 1, 0, '', ''),
(11, 'fdssr4534534dfgfdgdfg', 'Не окнами едиными', 'Не окнами едиными', '<div class="views-field views-field-body">\r\n<div class="field-content">\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">В преддверии Нового 2012 года&nbsp; в компани</span></span></span><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"><span style="color: #000000;">и по производству </span><a href="http://oknadnepr.com.ua/"><span style="color: #000000;">металлопластиковых окон</span></a><span style="color: #000000;"> в Павлограде &laquo;Открытые окна&raquo; воз</span></span></span><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">ник  вопрос: как провести корпоративную вечеринку? Как правило, перед Новым  годом, сотрудники предприятий в узком кругу могут отдохнуть и подвести  итоги уходящего года.</span></span></span></p>\r\n</div>\r\n</div>', '', '', 'Не окнами едиными', '', '', 1359583200, 1, 0, '', ''),
(12, 'novaya-fur', 'Новая фурнитура – новые возможности', 'Новая фурнитура – новые возможности', '<p><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Наши клиенты хотят максимально обезопасить свой дом, офис или любое другое помещение от взлома или не желат</span></span></span><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"><span style="color: #000000;">ельного проникновения. Компания &laquo;Открытые окна</span></span></span><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"><span style="color: #000000;">&raquo;</span></span></span><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"> внедрила в производство новую, более инновационную,&nbsp; линейку немецкой  фурнитуры для окон Winkhaus - а именно систему Activ Pilot. <br /></span></span></span></p>', '', '', '', '', '', 1359583200, 1, 0, '', ''),
(13, 'dsfkk', 'Боремся за звание лучших', 'Боремся за звание лучших', '<div class="views-field views-field-body">\r\n<div class="field-content">\r\n<p class="rteindent1"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"><span style="color: #000000;">Компания &laquo;Открытые окна</span></span></span><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"><a href="http://oknadnepr.com.ua/"></a><span style="color: #000000;">&raquo;  успешно борется за звание &laquo;Авторизованный партнер REHAU&raquo;, постоянно  работая над улучшением качества предоставляемых клиентам услуг. Статус  авторизованного партнера компания REHAU присваивает только тем  компаниям, которые соответствуют требуемым нормам.</span></span></span></p>\r\n</div>\r\n</div>', '', '', '', '', '', 1359583200, 1, 0, '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `pages_id` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(11) NOT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `visibility` tinyint(1) NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `menu_name` varchar(255) NOT NULL,
  `h1` varchar(255) NOT NULL,
  `meta_title` text NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `short_text` text NOT NULL,
  `text` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `img_alt` varchar(255) NOT NULL,
  `img_title` varchar(255) NOT NULL,
  `add_1` text NOT NULL,
  `add_2` text NOT NULL,
  `date` int(11) NOT NULL,
  `module` varchar(50) NOT NULL,
  `in_last` tinyint(1) NOT NULL,
  PRIMARY KEY (`pages_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=98 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`pages_id`, `root`, `lft`, `rgt`, `level`, `url`, `visibility`, `in_menu`, `menu_name`, `h1`, `meta_title`, `meta_keywords`, `meta_description`, `short_text`, `text`, `img`, `img_alt`, `img_title`, `add_1`, `add_2`, `date`, `module`, `in_last`) VALUES
(33, 33, 1, 26, 1, 'header_menu', 1, 0, 'Горизонтальное меню', 'Горизонтальное меню', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(34, 34, 1, 10, 1, 'produktsiya', 1, 1, 'Продукция', 'Продукция', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(35, 35, 1, 8, 1, 'test', 1, 1, 'Материалы', 'Материалы', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(36, 33, 12, 13, 2, 'kontaktyi1', 1, 1, 'Контакты', 'Контакты1', '123', '1', '123', '<p>123213</p>', '<p>213wqewqe</p>', '', '', '', '', '', 0, '', 0),
(38, 34, 2, 3, 2, 'derevyannyie_okna', 1, 1, 'Деревянные окна', 'Деревянные окна', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(40, 33, 2, 3, 2, 'main', 1, 1, 'Главная', 'Главная страница', 'Немецкое качество', 'Немецкое качество', 'Немецкое качество', '', '<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Окна  Rehau производятся на собственном производстве на высокотехнологичном  оборудовании. Наличие современного оборудования в производстве позволяет  достичь высочайшего качества окон. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Собственный  транспорт позволяет поддерживать на должном уровне доставку готовых  изделий в любой населенный пункт Днепропетровской области. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Уже  4 года предприятие &laquo;Открытые Окна&raquo; устанавливает окна в  Днепропетровске, Днепродзержинске, Царичанке, Першотравенске,  Синельниково, Петриковке, Терновке и других населенных пунктах области.</span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Наличие  собственного производства, монтажных бригад и центра сервисного  обслуживания окон (ЦСО) позволяет нам обеспечить максимальный контроль  на всех этапах работы.</span></span></span></p>\r\n<p class="rteindent1">&nbsp;</p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Окна  Rehau производятся на собственном производстве на высокотехнологичном  оборудовании. Наличие современного оборудования в производстве позволяет  достичь высочайшего качества окон. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Собственный  транспорт позволяет поддерживать на должном уровне доставку готовых  изделий в любой населенный пункт Днепропетровской области. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Уже  4 года предприятие &laquo;Открытые Окна&raquo; устанавливает окна в  Днепропетровске, Днепродзержинске, Царичанке, Першотравенске,  Синельниково, Петриковке, Терновке и других населенных пунктах области.</span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Наличие  собственного производства, монтажных бригад и центра сервисного  обслуживания окон (ЦСО) позволяет нам обеспечить максимальный контроль  на всех этапах работы.</span></span></span></p>\r\n<p class="rteindent1">&nbsp;</p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Окна  Rehau производятся на собственном производстве на высокотехнологичном  оборудовании. Наличие современного оборудования в производстве позволяет  достичь высочайшего качества окон. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Собственный  транспорт позволяет поддерживать на должном уровне доставку готовых  изделий в любой населенный пункт Днепропетровской области. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Уже  4 года предприятие &laquo;Открытые Окна&raquo; устанавливает окна в  Днепропетровске, Днепродзержинске, Царичанке, Першотравенске,  Синельниково, Петриковке, Терновке и других населенных пунктах области.</span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Наличие  собственного производства, монтажных бригад и центра сервисного  обслуживания окон (ЦСО) позволяет нам обеспечить максимальный контроль  на всех этапах работы.</span></span></span></p>\r\n<p class="rteindent1">&nbsp;</p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Окна  Rehau производятся на собственном производстве на высокотехнологичном  оборудовании. Наличие современного оборудования в производстве позволяет  достичь высочайшего качества окон. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Собственный  транспорт позволяет поддерживать на должном уровне доставку готовых  изделий в любой населенный пункт Днепропетровской области. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Уже  4 года предприятие &laquo;Открытые Окна&raquo; устанавливает окна в  Днепропетровске, Днепродзержинске, Царичанке, Першотравенске,  Синельниково, Петриковке, Терновке и других населенных пунктах области.</span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Наличие  собственного производства, монтажных бригад и центра сервисного  обслуживания окон (ЦСО) позволяет нам обеспечить максимальный контроль  на всех этапах работы.</span></span></span></p>\r\n<p class="rteindent1">&nbsp;</p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Окна  Rehau производятся на собственном производстве на высокотехнологичном  оборудовании. Наличие современного оборудования в производстве позволяет  достичь высочайшего качества окон. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Собственный  транспорт позволяет поддерживать на должном уровне доставку готовых  изделий в любой населенный пункт Днепропетровской области. </span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Уже  4 года предприятие &laquo;Открытые Окна&raquo; устанавливает окна в  Днепропетровске, Днепродзержинске, Царичанке, Першотравенске,  Синельниково, Петриковке, Терновке и других населенных пунктах области.</span></span></span></p>\r\n<p class="rteindent1"><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Наличие  собственного производства, монтажных бригад и центра сервисного  обслуживания окон (ЦСО) позволяет нам обеспечить максимальный контроль  на всех этапах работы.</span></span></span></p>', '', '', '', '', '', 0, '', 0),
(42, 75, 4, 5, 2, 'novosti', 1, 1, 'Новости', 'Новости', 'Новости', 'Новости', 'Новости', '', '', '', '', '', '', '', 0, 'news', 0),
(44, 33, 8, 9, 2, 'tsenyi_na_okna', 1, 1, 'Цены на окна', 'Цены на окна', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(68, 33, 10, 11, 2, 'nashi_rabotyi', 1, 1, 'Наши работы', 'Наши работы', '', '', '', '', '', '', '', '', '', '', 0, 'works', 0),
(69, 33, 6, 7, 2, 'reviews', 1, 1, 'Отзывы клиентов', 'Отзывы клиентов', '', '', '', '', '', '', '', '', '', '', 0, 'reviews', 0),
(70, 33, 4, 5, 2, 'aktsii', 1, 1, 'Акции', 'Акции', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(72, 33, 16, 17, 2, 'kak_vyibrat_plastikovoe_okno', 1, 0, 'Как выбрать пластиковое окно выбрать пластиковое окно', 'Как выбрать пластиковое окно выбрать пластиковое окно выбрать пластиковое окно выбрать пластиковое окно выбрать пластиковое окно', '', '', '', '<p>На рынке деревянных окон существует множество предприятий, которые изготавливают деревянные окна.</p>', '<p>На рынке деревянных окон существует множество предприятий, которые изготавливают деревянные окна.</p>', '', '', '', '', '', 1359489600, '', 1),
(73, 33, 14, 15, 2, 'karta_sayta', 1, 0, 'Карта сайта', 'Карта сайта', '', '', '', '', '', '', '', '', '', '', 0, 'sitemap', 0),
(74, 74, 1, 6, 1, 'uslugi', 1, 1, 'Услуги', 'Услуги', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(75, 75, 1, 6, 1, 'o_kompanii', 1, 1, 'О компании', 'О компании', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(76, 34, 4, 5, 2, 'plastikovyie_okna', 1, 1, 'Пластиковые окна', 'Пластиковые окна', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(77, 34, 6, 7, 2, 'jalyuzi', 1, 1, 'Жалюзи', 'Жалюзи', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(78, 34, 8, 9, 2, 'rolletyi', 1, 1, 'Роллеты', 'Роллеты', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(79, 35, 2, 3, 2, 'steklopaketyi', 1, 1, 'Стеклопакеты', 'Стеклопакеты', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(80, 35, 4, 5, 2, 'furnitura', 1, 1, 'Фурнитура', 'Фурнитура', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(81, 35, 6, 7, 2, 'otkosyi', 1, 1, 'Откосы', 'Откосы', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(82, 74, 2, 3, 2, 'uslugi2', 1, 1, 'Услуги', 'Услуги', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(83, 74, 4, 5, 2, 'zamer', 1, 1, 'Замер', 'Замер', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(84, 75, 2, 3, 2, 'novaya_stranitsa', 1, 1, 'Новая страница', 'Новая страница', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(85, 85, 1, 18, 1, 'nash_blog', 1, 1, 'Наш блог', 'Наш блог', '', '', '', '', '', '', '', '', '', '', 0, '', 0),
(86, 85, 2, 3, 2, 'okna', 1, 1, 'Окна', 'Окна', '', '', '', '', '', '86_okna.jpg', '', '', '', '', 0, '', 0),
(87, 85, 4, 5, 2, 'dveri', 1, 1, 'Двери', 'Двери', '', '', '', '', '', '87_dveri.jpg', '', '', '', '', 0, '', 0),
(88, 85, 6, 7, 2, 'balkonyi_lodjii', 1, 1, 'Балконы, лоджии', 'Балконы, лоджии', '', '', '', '', '', '88_balkoni_lodjii.jpg', '', '', '', '', 0, '', 0),
(89, 85, 8, 9, 2, 'fasadyi', 1, 1, 'Фасады', 'Фасады', '', '', '', '', '', '89_fasadi.jpg', '', '', '', '', 0, '', 0),
(90, 85, 10, 11, 2, 'rulonnyie_shtoryi', 1, 1, 'Рулонные шторы', 'Рулонные шторы', '', '', '', '', '', '90_rulonnie_shtori.jpg', '', '', '', '', 0, '', 0),
(91, 85, 12, 13, 2, 'podokonniki', 1, 1, 'Подоконники', 'Подоконники', '', '', '', '', '', '91_podokonniki.jpg', '', '', '', '', 0, '', 0),
(92, 85, 14, 15, 2, 'roletyi', 1, 1, 'Ролеты', 'Ролеты', '', '', '', '', '', '92_roleti.jpg', '', '', '', '', 0, '', 0),
(93, 85, 16, 17, 2, 'vorota', 1, 1, 'Ворота', 'Ворота', '', '', '', '', '', '93_vorota.jpg', '', '', '', '', 0, '', 0),
(94, 33, 18, 19, 2, 'vyibiraem_derevyannoe_okno', 1, 0, 'Выбираем деревянное окно ', 'Выбираем деревянное окно ', '', '', '', '<p>На рынке деревянных окон существует множество предприятий, которые изготавливают деревянные окна.</p>', '<p>На рынке деревянных окон существует множество предприятий, которые изготавливают деревянные окна. Среди этих предприятий многие стараются удешевить изготовление деревянного окна за счет экономии на комплектующих и за счет недорогого сырья. Лишь немногие предлагают к продаже именно качественные деревянные окна. Мы с вами понимаем, что окна &ndash; это не только элемент интерьера, а также конструктивный и многофункциональный элемент здания. Сквозь окна в дом попадает солнечный свет, именно окна мы ежедневно используем с целью проветривания помещений. Окна должны нести своим хозяевам не только комфорт, но и эстетическое и моральное удовлетворение от правильно сделанного выбора.</p>', '', '', '', '', '', 1356984000, '', 1),
(95, 33, 20, 23, 2, 'osobennosti_montaja_okon', 1, 0, 'Особенности монтажа окон', 'Особенности монтажа окон', '', '', '', '<p><span style="font-family: tahoma, geneva, sans-serif; color: #000000;">При выборе поставщика окон обратите внимание на то, как предприятие производит установку окна. </span></p>', '<p><span style="font-family: tahoma, geneva, sans-serif; color: #000000;">При выборе поставщика окон обратите внимание на то, как предприятие производит установку окна. </span></p>', '', '', '', '', '', 1359662400, '', 1),
(96, 33, 21, 22, 3, 'na_chto_stoit_obratit_vnimanie_pri_vyibore_firmyi-izgotovitelya_okon_pvh', 1, 0, 'На что стоит обратить внимание при выборе фирмы-изготовителя окон ПВХ', 'На что стоит обратить внимание при выборе фирмы-изготовителя окон ПВХ', '', '', '', '', '', '', '', '', '', '', 1359921600, '', 1),
(97, 33, 24, 25, 2, 'zayavka-otpravlena', 1, 0, 'Заявка отправлена', 'Заявка отправлена', '', '', '', '', '', '', '', '', '', '', 1359921600, '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `reviews_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(255) NOT NULL,
  `link_to_video` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `visibility` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `short_text` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `img_alt` varchar(255) NOT NULL,
  `img_title` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`reviews_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`reviews_id`, `menu_name`, `link_to_video`, `text`, `user_address`, `visibility`, `position`, `user_name`, `short_text`, `img`, `img_alt`, `img_title`, `date`) VALUES
(1, 'Сначала решили заменить часть окон', '', '', 'Жмайло Елена Александровна, с. Вербки, Павлоградский р-н.', 1, 2, '', '', '', '', '', 0),
(2, 'Работа очень понравилась – опять обратились в «Открытые Окна»', '', '', 'Бондаренко Антонина Николаевна, г. Павлоград', 0, 1, '', '', '', '', '', 0),
(3, 'Ждем зиму с нетерпением.', '', '', 'Романцова Людмила Викторовна, с. Вербоватовка, Павлоградский р-н', 0, 3, '', '', '', '', '', 0),
(4, 'Новый дом, новые окна!', '', '', 'Громова Яна Викторовна, с. Вербоватовка, Павлоградский р-н', 0, 4, '', '', '', '', '', 0),
(5, 'Нам очень понравилось качество окон.', '', '', 'Пробачай Надежда Васильевна, г. Павлоград', 0, 5, '', '', '', '', '', 0),
(6, 'Оформил заказ в «Открытых окнах» и не прогадал.', '', '', '', 0, 6, '', '', '', '', '', 0),
(7, 'Выбрали "Открытые Окна" и остались довольны.', '', '', '', 0, 7, '', '', '', '', '', 0),
(8, '"Открытые Окна" будем советовать друзьям и знакомым.', '', '', '', 0, 8, '', '', '', '', '', 0),
(9, 'Окна с видом на лес.', '', '', '', 0, 9, '', '', '', '', '', 0),
(10, 'Думали, если установим металлопластиковые окна - влажности станет меньше. Так и произошло...', '', '', '', 0, 10, '', '', '', '', '', 0),
(11, 'Прежде, чем менять окна, я советовался...', '', '', '', 0, 11, '', '', '', '', '', 0),
(12, 'Прежде, чем менять окна', '', '<p>Теперь у нас в доме стало теплее и красивее. Меньше шума, потому что нам установили окна с 2-х камерными стеклопакетами.</p>', 'г. Терновка', 1, 13, 'Ильяшевич Екатерина Валентиновна', '<p>Сначала мы решили заменить и заменили два окна &ndash; остались довольны.</p>', '12_balkoni_lodjii.jpg', '', '', 1357070400),
(13, 'Думали, если установим металлопластиковые', '', '', '333', 1, 14, '123', '', '13_balkoni_lodjii.jpg', '2', '1', 1356984000);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `key`, `name`, `value`) VALUES
(1, 'news_name_page', 'Количество новостей на страницу', '3'),
(2, 'form_email', 'Email получателя заявок', 'egor.developer@gmail.com'),
(3, 'admin_email', 'Email администратора сайта', 'egor.developer@gmail.com');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `users_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `role` varchar(10) NOT NULL,
  PRIMARY KEY (`users_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`users_id`, `email`, `password`, `name`, `role`) VALUES
(1, 'egor.developer@gmail.com', '06dc5813908303f4f64c3594dad50501', 'Егор', 'admin');

-- --------------------------------------------------------

--
-- Структура таблицы `works`
--

CREATE TABLE IF NOT EXISTS `works` (
  `works_id` int(11) NOT NULL AUTO_INCREMENT,
  `visibility` tinyint(1) NOT NULL,
  `menu_name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `img_big` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `img_alt` varchar(255) NOT NULL,
  `img_title` varchar(255) NOT NULL,
  `img_big_alt` varchar(255) NOT NULL,
  `img_big_title` varchar(255) NOT NULL,
  PRIMARY KEY (`works_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `works`
--

INSERT INTO `works` (`works_id`, `visibility`, `menu_name`, `text`, `img`, `img_big`, `address`, `position`, `img_alt`, `img_title`, `img_big_alt`, `img_big_title`) VALUES
(1, 1, '123123', '<p>123213</p>', '1_diamondAllianceIndexCal-03.jpg', '1_111.jpg', '123123', 1, '123', '123213', '21321', '213213'),
(2, 1, 'Пляжный сезон круглый год!', '<p><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Порой нашему предприятию приходится браться за нестандартные виды работ и работать с другими мате</span></span></span><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"><span style="color: #000000;">риалами, кроме </span></span></span><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"><span style="color: #000000;">окон ПВХ</span></span></span><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"><span style="color: #000000;"> </span></span></span><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;"><span style="color: #000000;">и </span><a href="http://oknadnepr.com.ua/"><span style="color: #000000;">деревянных окон</span></a><span style="color: #000000;">. В данном с</span></span></span><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">лучае  был использован алюминиевый профиль Talisman. Необходимо было сделать  витражную конструкцию для помещения, в котором находится бассейн. В  результате, бассейн от улицы отделила надежная остеклённая  энергосберегающими стеклопакетами с применением стекла &laquo;триплекс&raquo; стена.  А чтобы внутрь не проникали жаркие лучи и нежелательные взгляды &ndash;  стеклопакеты покр</span></span></span><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">ыли  специальной светоотражающей плёнкой. &nbsp;В итоге, убедитесь сами, стройка  еще не окончена, а витраж придает зданию презентабельный вид.</span></span></span></p>', '', '', 'Днепропетровская обл. с. Межиричи, И.В.', 2, '', '', '', ''),
(3, 1, 'Мелочь, а приятно!', '<p><span style="color: #000000;"><span style="font-size: 12px;"><span style="font-family: tahoma,geneva,sans-serif;">Окна  нестандартных форм - это ещё один пример того, как важно правильно и с  душой оформить своё жилище. Казалось бы, ничего особенного, а на самом  деле, такие мелочи &ndash; важные составляющие комфортного и уютного дома! С  помощью таких окон ПВХ Вы решаете сразу несколько проблем: остекление  сложных фрагментов зданий, вентилирование нежилых помещений,  эстетическая составляющая строения и т.д. Вот и выходит, что мелочей в  деле остекления не бывает!</span></span></span></p>', '', '', 'Днепропетровская обл., г. Павлоград, ул. Восстания, Анастасия У.', 3, '', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
